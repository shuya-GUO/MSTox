Title: 
Sharing High-Quality LC-MS/MS Spectral Data of over 100 Emerging Chemical Risks in the Food Chain

General description: 
This dataset contains MS2 spectral data for 102 compounds identified as emerging chemical risks in the food chain by the European Food Safety Authority (EFSA) or classified as persistent, mobile, and toxic (PMT) compounds. The spectral data was collected at Wageningen Food Safety Research, part of Wageningen University and Research (The Netherlands), using an Orbitrap IQX instrument in positive ionization mode with a collision energy of 30. The pure standards were acquired as part of the project "Screening for emerging chemical risks in the food chain (SCREENER), EFSA (europa.eu)" and the dataset curation, refinement, and dissemination were funded by the Fair Data Fund 2023 grant (The FAIR Data Fund – 4TU.ResearchData). 

Specific information: 
We are sharing the spectral data (list of MS2 ions with respective intensities) in .mgf and .msp formats, along with compounds’ metadata inclding common chemical name, synonyms, retention times, molecular formulae, SMILES, InchIKeys and EFSA-sourced predicted toxicity and toxicological endpoints.

Contact information: 
Dr. Federico Padilla Gonzalez
Wageningen Food Safety Research
Wageningen, The Netherlands
federico.padillagonzalez@wur.nl

DOI: 10.4121/720eea22-0dee-4ea0-b5d2-fbc7b45095c4
Weblinks: https://massive.ucsd.edu/ProteoSAFe/dataset.jsp?task=c9e0b445d4704261abfadabf7d140e48

Type of license: CC0